## ------------------------------------------------------------------------
source('hw4_514.R')
library(MASS)
library(zeallot)
require(Matrix)
require("beepr")

n1=50; mu1=c(.5,.5);  cov1=diag(.2,2)
n2=40; mu2=c(1.5,1.5);cov2=diag(.1,2)
n3=30; mu3=c(1.5,0);  cov3=diag(.1,2)
mean.cov.list=list()
mean.cov.list[[1]]=list(n=50, mu=c(.5,.5),  cov=diag(.2,2))
mean.cov.list[[2]]=list(n=40, mu=c(1.5,1.5),cov=diag(.1,2))
mean.cov.list[[3]]=list(n=30, mu=c(1.5,0),  cov=diag(.1,2))

#c(X,y) %<-% generate.gaussian.data.class3(n1,mu1,cov1,n2,mu2,cov2,n3,mu3,cov3)
c(x,y) %<-% gen.gaussian.data.2d(mean.cov.list)
plot(x[1,],x[2,],pch=1,col=y+1,lwd=2,cex=1)


## ------------------------------------------------------------------------
one.hot <- function(Y){ 
	return(unname( as.matrix( as.data.frame( t( model.matrix(~ as.factor(y) + 0) ) ) ) )) }

## ------------------------------------------------------------------------
cost <- function(X,Y,b,w){
	H <- fwd.prop(X,b,w)
  	(-1/dim(X)[2]) * sum(  colSums( one.hot(Y) * log( H)) )}

## ------------------------------------------------------------------------
fwd.prop <- function( X, b ,w ){
	Z <- ( b %*% matrix( rep(1, dim(X)[2] ) , nrow = 1) + w %*% X)
	Z <-  exp( sweep(Z,2,apply(Z,2,max) ))
	H <- Z %*% (1/colSums( Z ) * Diagonal(dim(Z)[2]) 	)   
	return( as.matrix(H))  }

## ------------------------------------------------------------------------
print.fun('fwd.prop');
print.fun('cost');


## ---- echo = F-----------------------------------------------------------

bk.prop <- function(X,Y ,fprop ){
	M <- dim(X)[2]; E <- fprop - one.hot(Y) 
 	db <- (1/M) *   E   %*% 	rep(1,M )
	dw <- (1/M) *   E   %*% 	t(X)
	return( list( db = db , dw = dw ))
}
 

num.gradient <- function(cost,X,Y,b,w,g=1e-8 )  {
	db <- b
	for( i in 1:length(b) ) {
		bP <- bM <-b; bP[i] <- bP[i]+g; bM[i] <- bM[i]-g
		db[i] <- (cost(X, Y , bP , w ) - cost(X, Y, bM, w  ) ) / (2*g)  }
	dw <- w*0
	for( i in 1:nrow(w) ){
	for( j in 1:ncol(w) ) {
		wP <- wM <- w ; wP[i,j] <- wP[i,j]+g; wM[i,j] <- wM[i,j]-g
		dw[i,j] <- (cost(X, Y , b , wP ) - cost(X, Y, b, wM ) ) / (2*g)
	}}
return( list(db = db , dw =  dw) )} 


## ------------------------------------------------------------------------
print.fun('num.gradient');
print.fun('bk.prop');

dim(x)

b0 <- rnorm(3)
w0 <- matrix(rnorm(3*dim(x)[1]),3,dim(x)[1])

bk.prop(x,y ,fwd.prop(x,b0,w0) )
num.gradient(cost,x,y,b0,w0)



## ---- echo= F------------------------------------------------------------

softmax.fit <- function(X,Y,lr=.01,max.its=100 ){

	K <- length( unique( as.vector( Y ) ) )
	N <- dim(X)[1]; M <- dim(X)[2]
	b<- rnorm( K ) * .1
	W <- matrix( rnorm( K * N ) *.1 , K , N )
	blist <- wlist <- list()
	Costs <- gradlist <- peformance <- rep(NA,max.its)
 	Class  <-  sort(unique(as.vector(Y)))

	st <- system.time(
	for( i in 1:max.its ) {
		FP <- fwd.prop(X , b, W )
		peformance[i] <- sum(( Class[apply( FP , 2 , function( M ) which( M == max(M) ))] == Y) *1  ) / length(Y)
		Costs[i] <- (-1/M) * sum( colSums( one.hot(Y) * log(FP)) )
		BP <- bk.prop(X,Y,FP)
		b <- blist[[i]] <- b - lr * BP$db
		W <- wlist[[i]] <- W - lr * BP$dw
		gradlist[i] <-  norm( cbind(b,W) , "2")
	} )
	return( list ( b = b , W = W , st = st, wlist = wlist, peformance = peformance,
		blist = blist, costs = Costs, gradlist = gradlist ) )	
}

print.fun('softmax.fit');

## ------------------------------------------------------------------------
Predict <- function(X,Y,b,w){  
 	Classes  <-  sort(unique(as.vector(Y)))
 	Classes[apply( fwd.prop( X , b , w ), 2 , function( M ) 
		which( M == max(M) ) ) ] 	}

## ---- cache=T------------------------------------------------------------
fit <- softmax.fit(x,y,lr=.2,max.its = 2000)

newdat <- gen.gaussian.data.2d(mean.cov.list)


sum(( Predict(newdat[[1]], newdat[[2]], fit$b, fit$W) == newdat[[2]] )*1 ) / length(newdat[[2]])

px <-  seq(  min( newdat[[1]] )-.1 , max( newdat[[1]] )+.1  , .1 )
Colors <- c("red", "blue", "green")

plot(t(newdat[[1]]), pch = 16 , col = "white")
for( i in 1:length(px) ){
for( j in 1:length(px) ){
	points(  px[i], px[j] , pch = 3, col = Colors[
	Predict(  ( as.matrix( c( px[i], px[j] )  ) ), y , fit$b , fit$W)] )
}}

plotdat <- cbind( t(newdat[[1]]),   as.vector( newdat[[2]] ) )

apply( plotdat, 1 , function(A) points( A[1], A[2], col = Colors[A[3]], pch = 16 ) )

## ---- cache=T------------------------------------------------------------
n1=50; mu1=c(.5,.5);  cov1=diag(.2,2)
n2=40; mu2=c(1.5,2.); cov2=diag(.1,2)
n3=30; mu3=c(1.5,-1); cov3=diag(.1,2)
n4=30; mu4=c(2,0);    cov4=diag(.1,2)
n5=30; mu5=c(2,1);    cov5=diag(.1,2)

mean.cov.list=list()
mean.cov.list[[1]]=list(n=n1, mu=mu1,  cov=cov1)
mean.cov.list[[2]]=list(n=n2, mu=mu2,  cov=cov2)
mean.cov.list[[3]]=list(n=n3, mu=mu3,  cov=cov3)
mean.cov.list[[4]]=list(n=n4, mu=mu4,  cov=cov4)
mean.cov.list[[5]]=list(n=n5, mu=mu5,  cov=cov5)

#c(X,y) %<-% generate.gaussian.data.class3(n1,mu1,cov1,n2,mu2,cov2,n3,mu3,cov3)
c(x,y) %<-% gen.gaussian.data.2d(mean.cov.list)
#Y=one.hot(t(y))

fit <- softmax.fit(x,y,lr=.2,max.its = 2000)

newdat <- gen.gaussian.data.2d(mean.cov.list)


sum(( Predict(newdat[[1]], newdat[[2]], fit$b, fit$W) == newdat[[2]] )*1 ) / length(newdat[[2]])

px <-  seq(  min( newdat[[1]] )-.1 , max( newdat[[1]] )+.1  , .1 )
Colors <- c("red", "blue", "green", "purple", "gold")

plot(t(newdat[[1]]), pch = 16 , col = "white")
for( i in 1:length(px) ){
for( j in 1:length(px) ){
	points(  px[i], px[j] , pch = 3, col = Colors[
	Predict(  ( as.matrix( c( px[i], px[j] )  ) ), y , fit$b , fit$W)] )
}}

plotdat <- cbind( t(newdat[[1]]),   as.vector( newdat[[2]] ) )

apply( plotdat, 1 , function(A) points( A[1], A[2], col = Colors[A[3]], pch = 16 ) )



## ------------------------------------------------------------------------
weighthist <- function(BList, WList){
  WH <- matrix( NA , length(BList)  , 2 )
  for( i in 1:length(BList)){
    WH[i,1] <-  norm(BList[[i]],"2")
    WH[i,2] <-  norm(WList[[i]],"2") }
  return(WH) }

gradhist <- function(BList, WList){ 
  GH <- rep(NA, length(BList))
  for( i in 1:length(BList)){
  GH[i] <- ( norm( cbind( BList[[i]],WList[[i]] ) , "2")) }
  return(GH)
 }

## ---- cache=T------------------------------------------------------------
mtrain <- read.csv("mnist_train.csv" , header = F)
#mtrain <- read.csv("C:\\Users\\Administrator\\Downloads\\mnist_train.csv", header = F)
test <- read.csv("mnist_test.csv" , header = F)
colnames(test )[1] <- colnames(mtrain )[1] <- "Y"

set.seed(1)
mtrains <- mtrain[ sample( 1:nrow(mtrain) , 1000 ) , ]
mtrains <- as.matrix(mtrains)
 
nx <- unname( test[,-1] )
nx <- t(nx)
nx <- nx / 255
ny <-  unname( test[,1] )

x <- unname( mtrains[,-1] )
x <- t(x)
x <- x / 255
y <-  unname( mtrains[,1] )

fits <- fit <- softmax.fit( x , y, lr = .1 ,max.its= 100 );#beep("coin")

sum(( Predict(x,  y, fit$b, fit$W) == y )*1 ) / length(y)

sum(( Predict(nx,  ny, fit$b, fit$W) == ny )*1 ) / length(ny)

## ------------------------------------------------------------------------
par(mfrow=c(2,2) , mar=c(2.1,2.1,2.1,2.1) )
plot(fit$costs, main = "costs", ylab=" ")
plot(gradhist(fit$blist,fit$wlist) , main = "gradient", ylab=" ")
plot(fit$peformance, main = "performance", ylab=" ")
plot( sapply(fit$blist, function(BB) norm(BB,"2")) , main = "weights", ylab=" ", ylim = c(0,4))
points( sapply(fit$wlist, function(BB) norm(BB,"2")) , main = "weights", ylab=" ", col = "red")

## ----full_mnist_model, cache=TRUE----------------------------------------
x <- unname( mtrain[,-1] )
x <- t(x)
x <- x / 255
y <-  as.matrix( unname(  mtrain[,1] ))

fita <- fit <- softmax.fit( x , y, lr = .1 ,max.its= 100 ); beep("coin") 

sum(( Predict(x,  y, fit$b, fit$W) == y )*1 ) / length(y)
sum(( Predict(nx,  ny, fit$b, fit$W) == ny )*1 ) / length(ny)

## ------------------------------------------------------------------------
par(mfrow=c(2,2) , mar=c(2.1,2.1,2.1,2.1) )
plot(fit$costs, main = "costs", ylab=" ")
plot(gradhist(fit$blist,fit$wlist) , main = "gradient", ylab=" ")
plot(fit$peformance, main = "performance", ylab=" ")
plot( sapply(fit$blist, function(BB) norm(BB,"2")) , main = "weights", ylab=" ", ylim = c(0,4))
points( sapply(fit$wlist, function(BB) norm(BB,"2")) , main = "weights", ylab=" ", col = "red")

## ------------------------------------------------------------------------
pix <- cbind( t(fwd.prop(x , fit$b, fit$W )) , as.matrix(y) , 1:length(y))

for( j in seq(0,9, by = 2)){
par(mfrow=c(2,2) , mar=c(2.1,2.1,2.1,2.1) )
for( k in j:(j+1)){ 
no = k
pix0 <- pix[which(pix[,11] == no),]
fP <- fwd.prop( x , fit$b , fit$W )
minpix <- round( pix0[which( pix0[,no + 1 ] == min(pix0[,no + 1 ] ) ),,drop=F ], 4 )
maxpix <-  round(pix0[which( pix0[,no + 1 ] == max(pix0[,no + 1 ] ) ), ,drop=F], 4 )

Minpt <- paste0( "Prediction: ",   (which( minpix == max(minpix[,1:10] ) )-1), ", " , max(minpix[,1:10] ), "%") 
show_digit2(x[,minpix[,ncol(minpix)]], main = Minpt )
Maxpt <- paste0( "Prediction: ",   (which( maxpix == max(maxpix[,1:10] ) )-1), ", " , max(maxpix[,1:10] ), "%") 
show_digit2(x[,maxpix[,ncol(maxpix)]], main = Maxpt  )
}}




## ---- cache=T------------------------------------------------------------
fit1 <- softmax.fit( x , y, lr = .5 ,max.its= 1000 );#
sum(( Predict(x,  y, fit1$b, fit1$W) == y )*1 ) / length(y)
sum(( Predict(nx,  ny, fit1$b, fit1$W) == ny )*1 ) / length(ny)

fit2 <- softmax.fit( x , y, lr = 1 ,max.its= 50 );#beep("coin")
sum(( Predict(x,  y, fit2$b, fit2$W) == y )*1 ) / length(y)
sum(( Predict(nx,  ny, fit2$b, fit2$W) == ny )*1 ) / length(ny)


## ---- cache=T------------------------------------------------------------
fit3 <- softmax.fit( x , y, lr = 2 ,max.its= 50 );#beep("coin")
sum(( Predict(x,  y, fit3$b, fit3$W) == y )*1 ) / length(y)
sum(( Predict(nx,  ny, fit3$b, fit3$W) == ny )*1 ) / length(ny)


## ---- cache=T------------------------------------------------------------
fit4 <- softmax.fit( x , y, lr = 5 ,max.its= 50 );#beep("coin")
sum(( Predict(x,  y, fit4$b, fit4$W) == y )*1 ) / length(y)
sum(( Predict(nx,  ny, fit4$b, fit4$W) == ny )*1 ) / length(ny)


## ------------------------------------------------------------------------
par(mfrow=c(2,2) , mar=c(2.1,2.1,2.1,2.1) )
plot(fit1$costs, main = "lr = .5, max.its= 1000", ylab=" ")
plot(fit2$costs, main = "lr = 1, max.its= 50", ylab=" ")
plot(fit3$costs, main = "lr = 2, max.its= 50", ylab=" ")
plot(fit4$costs, main = "lr = 5, max.its= 50", ylab=" ")

## ------------------------------------------------------------------------
fita$st

